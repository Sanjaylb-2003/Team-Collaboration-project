import { useEffect, useState } from 'react';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import './App.css';

function App() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8081/students')
      .then((res) => res.json())
      .then((data) => {
        console.log(data); // Correctly log the fetched data
        setData(data); // Update the state with fetched data
      })
      .catch((err) => console.error('Error fetching data:', err));
  }, []); // Dependency array to ensure useEffect runs only once

  return (
    <div>
      <h1>Users Table</h1>
      <table border="1">
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Department</th>
          </tr>
        </thead>
        <tbody>
          {data.map((d, i) => (
            <tr key={i}>
              <td>{d.name}</td>
              <td>{d.age}</td>
              <td>{d.dept}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
